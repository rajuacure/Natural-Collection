// আপনার নিজের কম্পিউটারে একবার চালাবেন। এই ফাইল ও key কখনো GitHub-এ দেবেন না।
// ব্যবহার: node set-admin.js admin@email.com
const admin = require('firebase-admin');
admin.initializeApp({ credential: admin.credential.cert(require('./serviceAccountKey.json')) });
(async () => {
  const user = await admin.auth().getUserByEmail(process.argv[2]);
  await admin.auth().setCustomUserClaims(user.uid, { admin: true });
  console.log('Admin সেট হয়েছে:', user.email, '— এখন logout করে আবার login করুন।');
})().catch(e => { console.error(e.message); process.exit(1); });
