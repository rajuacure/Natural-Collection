# NenVai — ধাপ ১ ও ২ (Admin Login + Product Management)

## Setup
1. console.firebase.google.com → Add project → "nenvai".
2. Build > Authentication > Get started > Email/Password চালু করুন। Users ট্যাবে নিজের admin ইমেইল যোগ করুন।
3. Build > Firestore Database > Create (production mode)। Region: asia-south1 (বা কাছাকাছি)।
4. Build > Storage > Get started।
5. Project settings > Web app (</>) যোগ করে config কপি করে `firebase-config.js`-এ বসান।
6. Rules deploy: `npm i -g firebase-tools && firebase login && firebase init` (Firestore ও Storage বাছুন, existing rules ফাইল রাখুন) তারপর `firebase deploy --only firestore:rules,storage`।
7. Admin role: Project settings > Service accounts > Generate new private key → `functions-setup/serviceAccountKey.json` নামে রাখুন (শুধু আপনার কম্পিউটারে, GitHub-এ নয়)।
   `cd functions-setup && npm i firebase-admin && node set-admin.js আপনার@ইমেইল`
8. Firebase Authentication > Settings > Authorized domains-এ `nenvai.com` ও `YOUR_NAME.github.io` যোগ করুন।
9. GitHub repo-তে এই ফাইলগুলো (serviceAccountKey.json বাদে) push করে Pages চালু করুন। Admin URL: `/admin.html`।

## পরীক্ষা
- Admin ইমেইলে login → dashboard খুলবে।
- সাধারণ user দিয়ে login → "Admin অনুমতি নেই" দেখাবে।
- প্রোডাক্ট যোগ (ছবিসহ) → এডিট → ডিলিট।
