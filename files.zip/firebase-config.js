// Firebase Console > Project settings > Your apps > Web app থেকে নিজের config বসান।
// এই config public হওয়া নিরাপদ। Service-account key এখানে কখনো রাখবেন না।
export const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.firebasestorage.app",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};
